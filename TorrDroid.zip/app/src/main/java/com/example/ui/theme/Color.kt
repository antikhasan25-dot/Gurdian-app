package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFFA2C8FF)
val BlueGrey80 = Color(0xFFBCC7DB)
val Teal80 = Color(0xFFA0D4D4)

val Blue40 = Color(0xFF1E3C72)
val BlueGrey40 = Color(0xFF425E80)
val Teal40 = Color(0xFF00696B)

val SlateBackground = Color(0xFFF8FAFC)
val CardSurface = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)

