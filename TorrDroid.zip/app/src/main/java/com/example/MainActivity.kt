package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.admin.DeviceAdminManager
import com.example.ui.AuthScreen
import com.example.ui.GuardianDashboardScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GuardianViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: GuardianViewModel by viewModels()
    private lateinit var deviceAdminManager: DeviceAdminManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        deviceAdminManager = DeviceAdminManager(this)
        if (!deviceAdminManager.isAdminActive()) {
            deviceAdminManager.requestAdminPermission(this, 1001)
        }

        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val authState by viewModel.authState.collectAsState()

                    if (authState is GuardianViewModel.AuthState.Authenticated) {
                        GuardianDashboardScreen(viewModel = viewModel)
                    } else {
                        AuthScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

