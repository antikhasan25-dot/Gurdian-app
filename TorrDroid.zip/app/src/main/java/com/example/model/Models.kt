package com.example.model

data class ChildProfile(
    val id: String,
    val name: String,
    val age: Int,
    val deviceName: String
)

data class DeviceStatus(
    val deviceId: String,
    val deviceName: String,
    val batteryLevel: Int,
    val isOnline: Boolean,
    val lastSyncTime: String,
    val screenTimeMinutes: Int,
    val screenTimeLimitEnabled: Boolean,
    val appLockEnabled: Boolean
)

data class SafetyRule(
    val id: String,
    val title: String,
    val description: String,
    val type: String,
    val enabled: Boolean
)
