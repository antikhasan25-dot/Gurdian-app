package com.example.firebase

import com.example.model.DeviceStatus
import com.example.model.SafetyRule
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

class FirebaseGuardianHelper {

    private val auth: FirebaseAuth? by lazy {
        runCatching { FirebaseAuth.getInstance() }.getOrNull()
    }

    private val database: FirebaseDatabase? by lazy {
        runCatching { FirebaseDatabase.getInstance() }.getOrNull()
    }

    val currentUid: String?
        get() = auth?.currentUser?.uid

    val currentUserEmail: String?
        get() = auth?.currentUser?.email

    suspend fun syncDeviceStatus(uid: String, deviceStatus: DeviceStatus) {
        val db = database ?: return
        runCatching {
            val ref = db.getReference("parents/$uid/devices/${deviceStatus.deviceId}")
            val map = mapOf(
                "deviceId" to deviceStatus.deviceId,
                "deviceName" to deviceStatus.deviceName,
                "batteryLevel" to deviceStatus.batteryLevel,
                "isOnline" to deviceStatus.isOnline,
                "lastSyncTime" to deviceStatus.lastSyncTime,
                "screenTimeMinutes" to deviceStatus.screenTimeMinutes,
                "screenTimeLimitEnabled" to deviceStatus.screenTimeLimitEnabled,
                "appLockEnabled" to deviceStatus.appLockEnabled
            )
            ref.setValue(map).await()
        }
    }

    suspend fun syncSafetyRule(uid: String, rule: SafetyRule) {
        val db = database ?: return
        runCatching {
            val ref = db.getReference("parents/$uid/rules/${rule.id}")
            val map = mapOf(
                "id" to rule.id,
                "title" to rule.title,
                "description" to rule.description,
                "type" to rule.type,
                "enabled" to rule.enabled
            )
            ref.setValue(map).await()
        }
    }
}
