package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.firebase.FirebaseGuardianHelper
import com.example.model.ChildProfile
import com.example.model.DeviceStatus
import com.example.model.SafetyRule
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GuardianViewModel : ViewModel() {

    sealed class AuthState {
        object Idle : AuthState()
        object Loading : AuthState()
        object Authenticated : AuthState()
        data class Error(val message: String) : AuthState()
    }

    private val firebaseHelper = FirebaseGuardianHelper()

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _isDemoMode = MutableStateFlow(true)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    private val _parentEmail = MutableStateFlow<String?>("parent@example.com")
    val parentEmail: StateFlow<String?> = _parentEmail.asStateFlow()

    private val _childrenList = MutableStateFlow<List<ChildProfile>>(emptyList())
    val childrenList: StateFlow<List<ChildProfile>> = _childrenList.asStateFlow()

    private val _activeChild = MutableStateFlow<ChildProfile?>(null)
    val activeChild: StateFlow<ChildProfile?> = _activeChild.asStateFlow()

    private val _deviceStatus = MutableStateFlow<DeviceStatus?>(null)
    val deviceStatus: StateFlow<DeviceStatus?> = _deviceStatus.asStateFlow()

    private val _safetyRules = MutableStateFlow<List<SafetyRule>>(emptyList())
    val safetyRules: StateFlow<List<SafetyRule>> = _safetyRules.asStateFlow()

    init {
        val initialChildren = listOf(
            ChildProfile("c1", "Alex", 12, "Galaxy Tab A8"),
            ChildProfile("c2", "Maya", 9, "Pixel Tablet")
        )
        _childrenList.value = initialChildren
        _activeChild.value = initialChildren.first()

        _deviceStatus.value = DeviceStatus(
            deviceId = "dev_alex_01",
            deviceName = "Galaxy Tab A8",
            batteryLevel = 84,
            isOnline = true,
            lastSyncTime = getCurrentFormattedTime(),
            screenTimeMinutes = 105,
            screenTimeLimitEnabled = true,
            appLockEnabled = true
        )

        _safetyRules.value = listOf(
            SafetyRule(
                id = "r1",
                title = "Bedtime Screen Lock",
                description = "Automatically restrict access after 8:30 PM",
                type = "TIME_RESTRICTION",
                enabled = true
            ),
            SafetyRule(
                id = "r2",
                title = "App Installation Shield",
                description = "Require parent approval for downloading new apps",
                type = "APP_LOCK",
                enabled = true
            ),
            SafetyRule(
                id = "r3",
                title = "Safe Web Filter",
                description = "Enforce explicit content filtering policies",
                type = "WEB_FILTER",
                enabled = true
            )
        )

        checkCurrentAuth()
    }

    private fun checkCurrentAuth() {
        val email = firebaseHelper.currentUserEmail
        if (email != null) {
            _parentEmail.value = email
            _isDemoMode.value = false
            _authState.value = AuthState.Authenticated
        }
    }

    fun login(emailInput: String, passwordInput: String) {
        if (emailInput.isBlank() || passwordInput.isBlank()) {
            _authState.value = AuthState.Error("Email and Password cannot be empty.")
            return
        }

        _authState.value = AuthState.Loading

        val auth = runCatching { FirebaseAuth.getInstance() }.getOrNull()
        if (auth != null) {
            auth.signInWithEmailAndPassword(emailInput, passwordInput)
                .addOnSuccessListener { result ->
                    _parentEmail.value = result.user?.email ?: emailInput
                    _isDemoMode.value = false
                    _authState.value = AuthState.Authenticated
                    syncDataToFirebase()
                }
                .addOnFailureListener { e ->
                    _authState.value = AuthState.Error(e.message ?: "Authentication failed. You can use Demo Mode.")
                }
        } else {
            // Fallback for environment without Firebase Google Services active
            _parentEmail.value = emailInput
            _isDemoMode.value = true
            _authState.value = AuthState.Authenticated
        }
    }

    fun loginDemo() {
        _parentEmail.value = "demo.parent@childguardian.app"
        _isDemoMode.value = true
        _authState.value = AuthState.Authenticated
    }

    fun logout() {
        runCatching { FirebaseAuth.getInstance().signOut() }
        _authState.value = AuthState.Idle
    }

    fun toggleDemoMode() {
        _isDemoMode.value = !_isDemoMode.value
    }

    fun selectChild(child: ChildProfile) {
        _activeChild.value = child
        _deviceStatus.value = DeviceStatus(
            deviceId = "dev_${child.id}",
            deviceName = child.deviceName,
            batteryLevel = (70..98).random(),
            isOnline = true,
            lastSyncTime = getCurrentFormattedTime(),
            screenTimeMinutes = (30..180).random(),
            screenTimeLimitEnabled = true,
            appLockEnabled = true
        )
    }

    fun toggleScreenTimeLimit(enabled: Boolean) {
        val current = _deviceStatus.value ?: return
        val updated = current.copy(
            screenTimeLimitEnabled = enabled,
            lastSyncTime = getCurrentFormattedTime()
        )
        _deviceStatus.value = updated
        if (!_isDemoMode.value) {
            viewModelScope.launch {
                val uid = firebaseHelper.currentUid ?: "parent_uid"
                firebaseHelper.syncDeviceStatus(uid, updated)
            }
        }
    }

    fun toggleAppLock(enabled: Boolean) {
        val current = _deviceStatus.value ?: return
        val updated = current.copy(
            appLockEnabled = enabled,
            lastSyncTime = getCurrentFormattedTime()
        )
        _deviceStatus.value = updated
        if (!_isDemoMode.value) {
            viewModelScope.launch {
                val uid = firebaseHelper.currentUid ?: "parent_uid"
                firebaseHelper.syncDeviceStatus(uid, updated)
            }
        }
    }

    fun addChild(name: String, age: Int, deviceName: String) {
        val newChild = ChildProfile(
            id = "c_${System.currentTimeMillis()}",
            name = name,
            age = age,
            deviceName = deviceName
        )
        _childrenList.value = _childrenList.value + newChild
        selectChild(newChild)
    }

    fun addRule(title: String, description: String, type: String) {
        val newRule = SafetyRule(
            id = "r_${System.currentTimeMillis()}",
            title = title,
            description = description,
            type = type,
            enabled = true
        )
        _safetyRules.value = _safetyRules.value + newRule
        if (!_isDemoMode.value) {
            viewModelScope.launch {
                val uid = firebaseHelper.currentUid ?: "parent_uid"
                firebaseHelper.syncSafetyRule(uid, newRule)
            }
        }
    }

    fun toggleRule(rule: SafetyRule) {
        _safetyRules.value = _safetyRules.value.map {
            if (it.id == rule.id) it.copy(enabled = !it.enabled) else it
        }
    }

    fun deleteRule(rule: SafetyRule) {
        _safetyRules.value = _safetyRules.value.filter { it.id != rule.id }
    }

    fun refreshData() {
        val current = _deviceStatus.value ?: return
        _deviceStatus.value = current.copy(
            lastSyncTime = getCurrentFormattedTime(),
            batteryLevel = (current.batteryLevel - 1).coerceAtLeast(10)
        )
    }

    private fun syncDataToFirebase() {
        val uid = firebaseHelper.currentUid ?: return
        viewModelScope.launch {
            _deviceStatus.value?.let { status ->
                firebaseHelper.syncDeviceStatus(uid, status)
            }
            _safetyRules.value.forEach { rule ->
                firebaseHelper.syncSafetyRule(uid, rule)
            }
        }
    }

    private fun getCurrentFormattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }
}
